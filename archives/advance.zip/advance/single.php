
<?php get_header();
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Advance
 * @since Advance 1.0
 */

 ?>

  <?php get_template_part('content', 'single'); ?>
<?php get_footer(); ?>