jQuery(document).ready(function() {
	/* Move  widgets */
	
	wp.customize.section( 'sidebar-widgets-sidebar_frontpage' ).panel( 'theme_options' );
	wp.customize.section( 'sidebar-widgets-sidebar_frontpage' ).priority( '5' );
	
});


