<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 */
?>
 <!-- head select -->   
<?php  get_template_part('footer/part','footer1'); ?>
<!-- / head select --> 
<?php wp_footer(); ?>
</body>
</html>