<?php
/**
 * This file override default topmenu block for shopby various attributes
 *
 * @author Ktpl Team
 * @copyright Copyright (c) 2016 Ktpl (https://www.krishtechnolabs.com)
 * @package Ktpl_Topmenu
 */

namespace Ktpl\Topmenu\Block\Html;

use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\Data\TreeFactory;
use Magento\Framework\Data\Tree\Node;
use Magento\Framework\Data\Tree\NodeFactory;

class Topmenu extends \Magento\Theme\Block\Html\Topmenu
{
    protected $_ktplHelper;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Data\Tree\NodeFactory $nodeFactory,
        \Magento\Framework\Data\TreeFactory $treeFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Ktpl\General\Helper\Data $ktplhelper,
        array $data = []
    ){
        $this->_ktplHelper = $ktplhelper;
        parent::__construct($context,$nodeFactory,$treeFactory,$data);
    }

    /**
     * Add category image in submenu
     *
     * @param \Magento\Framework\Data\Tree\Node $child
     * @param string $childLevel
     * @param string $childrenWrapClass
     * @param int $limit
     * @return string HTML code
     */
    protected function _addSubMenu($child, $childLevel, $childrenWrapClass, $limit)
    { 
        $html = '';
        if (!$child->hasChildren()) {
            return $html;
        }

        $colStops = null;
        if ($childLevel == 0 && $limit) {
            $colStops = $this->_columnBrake($child->getChildren(), $limit);
        }
        /*if ($childLevel == 0) {  
            $html .= '<div class="ws-custom ui-menu">';
        }*/

        if ($childLevel == 1) {  
            echo $child->getChildren()->count();
            if($child->getChildren()->count()) {die('sfsdfds');
                foreach ($child as $subchild) {
                    echo "<pre/>"; print_r($subchild->getData());
                }
            }die;
        }
        
        $html .= '<ul class="level' . $childLevel . ' submenu">';
		/* Code to display category image START */
		$_categorypath = $this->getBaseMediaUrl('catalog/category/');
        $_categoryImage = $child->getImage();
        if($childLevel == 0 && $_categoryImage != null) {
            $newImageUrl = $this->_ktplHelper->resize('catalog/category/','category/resized/',$_categoryImage,300,300);
            $html .= '<div class="menu-category-img"><img src="'.$newImageUrl.'" alt="'.$child->getName().'"/></div>';    
        }
        /* Code to display category image END */
        $html .= $this->_getHtml($child, $childrenWrapClass, $limit, $colStops);
        
        
        /* Code to display static block START */
        $_staticBlockName = 'menu-block-'.$this->getStringSmallWithoutSpace($child->getName());
        $_megamenuBlock = trim($this->getLayout()->createBlock('Magento\Cms\Block\Block')->setBlockId($_staticBlockName)->toHtml());
        if($childLevel == 0 && $child->getMegamenuEnable() && $_megamenuBlock) {
        	$html .= '<div class="megamenu-static-block">'.$_megamenuBlock.'</div>';       
    	}
        /* Code to display static block START */
        $html .= '</ul>';      
        
        /*if ($childLevel == 0) {  
            $html .= '</div>';        
        }*/
        

        return $html;
    }

    /**
     * Recursively generates top menu html from data that is specified in $menuTree
     *
     * @param \Magento\Framework\Data\Tree\Node $menuTree
     * @param string $childrenWrapClass
     * @param int $limit
     * @param array $colBrakes
     * @return string
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function _getHtml(
        \Magento\Framework\Data\Tree\Node $menuTree,
        $childrenWrapClass,
        $limit,
        $colBrakes = []
    ) {
        $html = '';

        $children = $menuTree->getChildren();
        $parentLevel = $menuTree->getLevel();
        $childLevel = $parentLevel === null ? 0 : $parentLevel + 1;

        $counter = 1;
        $itemPosition = 1;
        $childrenCount = $children->count();

        $parentPositionClass = $menuTree->getPositionClass();
        $itemPositionClassPrefix = $parentPositionClass ? $parentPositionClass . '-' : 'nav-';

        foreach ($children as $child) {
            $child->setLevel($childLevel);
            $child->setIsFirst($counter == 1);
            $child->setIsLast($counter == $childrenCount);
            $child->setPositionClass($itemPositionClassPrefix . $counter);

            $outermostClassCode = '';
            $outermostClass = $menuTree->getOutermostClass();

            if ($childLevel == 0 && $outermostClass) {
                $outermostClassCode = ' class="' . $outermostClass . '" ';
                $child->setClass($outermostClass);
            }
            
            if (count($colBrakes) && $colBrakes[$counter]['colbrake']) {
                $html .= '</ul></li><li class="column"><ul>';
            }

            $html .= '<li ' . $this->_getRenderedMenuItemAttributes($child) . '>';
            $html .= '<a href="' . $child->getUrl() . '" ' . $outermostClassCode . '><span>' . $this->escapeHtml(
                $child->getName()
            ) . '</span></a>' . $this->_addSubMenu(
                $child,
                $childLevel,
                $childrenWrapClass,
                $limit
            ) . '</li>';
            $itemPosition++;
            $counter++;
        }

        if (count($colBrakes) && $limit) {
            $html = '<li class="column"><ul>' . $html . '</ul></li>';
        }

        return $html;
    }

    /**
     * Returns array of menu item's classes
     *
     * @param \Magento\Framework\Data\Tree\Node $item
     * @return array
     */
    protected function _getMenuItemClasses(\Magento\Framework\Data\Tree\Node $item)
    {
        $classes = [];
        
        $classes[] = 'level' . $item->getLevel();
        $classes[] = ($item->getMegamenuEnable()) ? ' megamenu': '';
        $classes[] = $item->getPositionClass();

        if ($item->getIsFirst()) {
            $classes[] = 'first';
        }

        if ($item->getIsActive()) {
            $classes[] = 'active';
        } elseif ($item->getHasActive()) {
            $classes[] = 'has-active';
        }

        if ($item->getIsLast()) {
            $classes[] = 'last';
        }

        if ($item->getClass()) {
            $classes[] = $item->getClass();
        }

        if ($item->hasChildren()) {
            $classes[] = 'parent';
        }

        return $classes;
    }

    /**
     * get Base Url Media.
     *
     * @param string $path   [description]
     * @param bool   $secure [description]
     * @return string [description]
     */
    public function getBaseMediaUrl($path = '', $secure = false)
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA, $secure) . $path;
    }

    protected function _toHtml()
    {
        $this->setModuleName($this->extractModuleName('Magento\Theme\Block\Html\Topmenu'));
        return parent::_toHtml();
    }

    /**
     * @param string [name]
     * @return string [name in lower case and replace space by underscore]
     */
    public function getStringSmallWithoutSpace($name)
    {
        return str_replace(array(' ','/'), array('-','-'), strtolower($name));
    }
}

