var config = {
    paths: {        	
            'insta': "Ktpl_General/js/instafeed.min"
        },   
    shim: {
		'insta': {
			deps: ['jquery']
		}
	}
};
