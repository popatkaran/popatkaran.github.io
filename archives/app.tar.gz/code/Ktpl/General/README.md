# Ktpl_General

* An extension from ktpl for all general settings for website.
* This overrides some blocks, models, controllers, templates which are use globally.
