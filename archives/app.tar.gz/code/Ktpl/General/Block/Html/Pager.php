<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ktpl\General\Block\Html;

/**
 * Html pager block
 * @SuppressWarnings(PHPMD.ExcessivePublicCount)
 */
class Pager extends \Magento\Theme\Block\Html\Pager
{
    
    /**
     * The list of available pager limits
     *
     * @var array
     */
    protected $_availableLimit = [5 => 5, 10 => 10, 20 => 20, 50 => 50];
}
