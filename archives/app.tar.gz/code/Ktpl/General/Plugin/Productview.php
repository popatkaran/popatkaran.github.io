<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ktpl\General\Plugin;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\Product;
use Closure;
/**
 * Product View block
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Productview extends \Magento\Catalog\Block\Product\View
{
    public function aroundGetProduct( 
        \Magento\Catalog\Block\Product\View $subject,
        Closure $proceed
    )
    {    	
    	$newdata = $proceed();
        $_stockandqty = $newdata->getQuantityAndStockStatus();
        $_stock = $_stockandqty['is_in_stock'];
        
        if(isset($_stock) && $_stock == '') {
            echo "<pre/>"; print_r($this->pageConfig);exit; 
            $this->pageConfig->addBodyClass('in-stock-product'); 
        }
        return $this;
    }
}