require([ 'jquery', 'jquery/ui'], function($){
		
	$(document).ready(function($) {					
	
		/* Megamenu*/
		jQuery('.nav-sections').before('<div id="navigation-toggle">Navigation Toggle</div>');
		jQuery('.navigation').addClass('megamenu');
		
		var divHeight = $('.navigation.megamenu').height(); 
        jQuery('.navigation .level0 > .submenu').css('min-height', divHeight+'px');
		
		$("#navigation-toggle").click(function(){
			jQuery(this).toggleClass("active");							
			jQuery(".nav-sections").toggleClass("show");							
		}); 
		
		$( ".navigation.megamenu li.level0" ).click(function( event ) {
		  event.stopPropagation();
		  // Do something
		});

		jQuery(".page-main, .columns").mousedown(function(){
			jQuery(".nav-sections").removeClass("show");				
			jQuery("#navigation-toggle").removeClass("active");				
		});
		
		/* Home top banner parallax */
		var offset = 1;
		jQuery(window).scroll(function() {			
			if (jQuery(this).scrollTop() > offset) {
				jQuery(".top-banner").addClass("parallax");
			}
			else {
				jQuery('.top-banner').removeClass("parallax");
			}		
		});	

		/* product listing page */
		jQuery(".product-discription .pro-info").mouseenter(function(){
			jQuery(this).next('.overlay').addClass("show");				
		});
		jQuery(".product-discription .desc-close").mouseenter(function(){
			jQuery(this).next('.overlay').addClass("show");				
		});
		$(".product-discription .desc-close").click(function(){
			jQuery(".product-discription .overlay").removeClass("show");							
		});  
		jQuery(".page-products .product-item, .page-products .sidebar, .page-products .page-main, .page-products .columns").mouseenter(function(){
			jQuery(".product-discription .overlay").removeClass("show");				
		});
		
	});
});