require([ 'jquery', 'jquery/ui'], function($){
	$(document).ready(function($) {					
		var divHeight = $('.navigation .level0 .submenu').height(); 
        jQuery('.navigation .level0 .submenu .submenu').css('min-height', divHeight+'px');			
		
		/*Back to Top and footer sticky jQuery*/		
		var offset = 1;			
		
		jQuery(window).scroll(function() {			
			if (jQuery(this).scrollTop() > offset) {
				jQuery(".top-banner").addClass("parallax");
			}
			else {
				jQuery('.top-banner').removeClass("parallax");
			}		
		});	

		jQuery(".product-discription .pro-info").mouseenter(function(){
			jQuery(".product-discription .overlay").addClass("show");				
		});
		jQuery(".page-products .product-item, .page-products .sidebar, .page-products .page-main, .page-products .columns").mouseenter(function(){
			jQuery(".product-discription .overlay").removeClass("show");				
		});
		
	});
});